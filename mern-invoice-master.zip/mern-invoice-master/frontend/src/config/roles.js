export const ROLES = {
  User: "User",
  Admin: "Admin",
};
