import AuthNav from "./AuthNav";

const Navbar = () => {
  return <AuthNav />;
};

export default Navbar;
