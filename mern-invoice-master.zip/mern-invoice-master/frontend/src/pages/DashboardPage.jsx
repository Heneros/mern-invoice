import React from "react";
import { Box, Container, CssBaseline, Grid, Typography } from "@mui/material";

export default function DashboardPage() {
  return (
    <Box sx={{ display: "flex", marginLeft: "250px", mt: 10 }}>
      <Typography variant="h3">This is dashboard</Typography>
    </Box>
  );
}
