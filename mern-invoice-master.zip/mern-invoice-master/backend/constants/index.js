export const ADMIN = "Admin";
export const USER = "User";
