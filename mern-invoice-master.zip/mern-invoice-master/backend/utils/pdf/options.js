export default {
	format: "A4",
	orientation: "portrait",
	border: "10mm",
	width: "950px",
};
